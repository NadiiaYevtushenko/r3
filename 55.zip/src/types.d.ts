interface Window {
    $: any;
    jQuery: any;
}